define([ "dojo/on", "dojo/_base/declare", "dojo/cache", "dijit/_Widget",
		"dijit/_TemplatedMixin", "dijit/_WidgetsInTemplateMixin", 
		"dojo/text!rca/resources/templates/appMain.html", "dojo/_base/lang", 
		"dojo/dom-form" , "dojo/json", "dijit/registry", "dojo/date",
		"dojo/domReady!",
		"dijit/layout/BorderContainer", "dijit/layout/ContentPane", 
		"dijit/form/DateTextBox", "dijit/form/TimeTextBox", 
		"dijit/form/Form" , "dijit/form/Button" , 
		"dojox/charting/Chart2D",
		"dojo/data/ItemFileWriteStore",
		"dojox/charting/plot2d/Bars"
		
		], 
		function(on, declare, cache, _Widget, _TemplatedMixin, _WidgetsInTemplateMixin, 
				template, lang, domForm, json, registry, date) {
	
		return declare('rca.appMain',[ _Widget, _TemplatedMixin,
			_WidgetsInTemplateMixin ], {
		
		templateString : template,
		
		baseClass: "appMain",
		
		// Path to the template
		

		// Override this method to perform custom behavior during dijit construction.
		// Common operations for constructor:
		// 1) Initialize non-primitive types (i.e. objects and arrays)
		// 2) Add additional properties needed by succeeding lifecycle methods
		constructor : function() {
			console.debug("I am inside constructor.");		
		},

		// When this method is called, all variables inherited from superclasses are 'mixed in'.
		// Common operations for postMixInProperties
		// 1) Modify or assign values for widget property variables defined in the template HTML file
		postMixInProperties : function() {
		},

		startup : function(){
			console.debug("Startup Function called.");
	    	   
		},
		
		// postCreate() is called after buildRendering().  This is useful to override when 
		// you need to access and/or manipulate DOM nodes included with your widget.
		// DOM nodes and widgets with the dojoAttachPoint attribute specified can now be directly
		// accessed as fields on "this". 
		// Common operations for postCreate
		// 1) Access and manipulate DOM nodes created in buildRendering()
		// 2) Add new DOM nodes or widgets 
		postCreate : function() {
			
			this.inherited(arguments);
			
		},
		
		
		fromTimeValueChanged : function(/* event */ event)
		{
//			require(['dojo/dom'], 
					//function(dom){dom.byId('val').value=dom.byId('toDateId').value.toString().replace(/.*1970\s(\S+).*/,'T$1')
				//});
			console.debug("fromDateChanged");	
			
			console.debug(event);
			
				
		},
		
		toTimeValueChanged : function(/* event */ event)
		{
			console.debug("toDateChanged");
			
			console.debug(event);
		},
		
		processServerSuccessResponse : function(jsonData) {
			
			console.debug("Successfully submitted form.");
			
			//var store = new dojo.data.ItemFileWriteStore({ url:"appMain.json" });
			
			var oldBars = registry.byId("initialMetricsChartId");
			
			if(oldBars)
				{
				console.debug("found old bars");
					oldBars.destroy();
				}
			
			bars = new dojox.charting.Chart("initialMetricsChartId",{
				title: "Performance Matrices",
    			titlePos: "bottom",
    			titleGap: 25,
    			titleFont: "normal normal normal 15pt 'Segoe UI'",
    			titleFontColor: "black"
			});
			
			
			//bars.setStore(store, {symbol:"*"}, "price");
			bars.addPlot("default", {type: dojox.charting.plot2d.Bars, length:10, minBarSize: 20, maxBarSize : 20});		
			bars.addAxis("x",{min:0, max: 1});
			bars.addAxis("y", {vertical: true, labels: jsonData['chart']['yAxis'] });						
			bars.addSeries("Series 1", jsonData['chart']['xAxis'], {stroke: {color:"rgb(0,0,80)"}, fill:"rgb(0,0,80)" }
    		);
			
			bars.render();
	    			
		},
			
		processServerErrorResponse : function(){
			console.debug("Failed in form submission.");
		},
		
		getDateTime : function(/*Date Widget*/ dateWidget,  /*Time Widget*/ timeWidget)
		{
			var date = dateWidget.displayedValue;

			var time = timeWidget.displayedValue;

			var dateArray = date.split('/');
			
			var timeArray = time.split(':');

			var hours = timeArray[0];

			var minutes = timeArray[1].split(" ")[0];
			
			var ampm = timeArray[1].split(" ")[1];

			if(ampm == "PM")
			{
				hours = parseInt(hours)+12;
			}

			if(parseInt(hours) < 10)
			{
				hours = "0"+hours;
			}

			

			return dateArray[2] + dateArray[0] + dateArray[1] + hours + minutes;

		},
		
		submitFormAsJson : function () {
			
			var toDateTime = this.getDateTime( dijit.byId("toDateId"), dijit.byId("toTimeId"));
			
			var fromDateTime = this.getDateTime( dijit.byId("fromDateId"), dijit.byId("fromTimeId"));

//			console.debug(toDateTime);
//			
//			var fromDate = dijit.byId("fromDateId").displayedValue;
//
//			var toDate = dijit.byId("toDateId").displayedValue;
//			
//			console.debug(fromDate);
//			
//			var dateArray = fromDate.split('/');
//
//			var fromDateTime = new Date(
//			dateArray[2], 
//			dateArray[0],
//			dateArray[1], "0","0","0","0");
//
//			var dateArray = toDate.split('/');
//
//			var toDateTime = new Date(
//			dateArray[2], 
//			dateArray[0],
//			dateArray[1], "0","0","0","0");
//
//			var toTime = dijit.byId("toTimeId").displayedValue;
//
//			var timeArray = toTime.split(':');
//
//			var hours = timeArray[0];
//
//			var minutes = timeArray[1].split(" ")[0];
//			var ampm = timeArray[1].split(" ")[1];
//
//			if(ampm == "PM")
//			{
//				hours = hours+12;
//			}
//
//			if(parseInt(hours) < 10)
//			{
//				hours = "0"+hours;
//			}
//
//			var toTimeToSend = "" + hours + minutes
			
			var successCallback = lang.hitch(this, "processServerSuccessResponse");
			
			var errorCallback = lang.hitch(this, "processServerErrorResponse");
		
			//var data = domForm.toJson("firstInputFormId");
			
			//var data = domForm.toJson("firstInputFormId");
			
			var requestBodyToServer = {fromDateTime : fromDateTime, toDateTime : toDateTime};

			var data = dojo.toJson(requestBodyToServer);
			
			var firstAnalysisService = {
					postData: data,					
					url: "service/firstAnalysis.do",
					handleAs: "json",
					method: "post",
					preventCache: true,
					headers: { "Content-Type": "application/json"},
					load: successCallback,
					error: errorCallback
			};
					
			dojo.xhrPost(firstAnalysisService);
							
		}
		

		

		
	});
	

    
});