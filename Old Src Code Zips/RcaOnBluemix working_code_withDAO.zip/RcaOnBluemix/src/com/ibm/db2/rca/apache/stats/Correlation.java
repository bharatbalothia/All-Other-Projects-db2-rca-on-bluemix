package com.ibm.db2.rca.apache.stats;

import java.util.List;
import java.util.Map;

import org.apache.commons.math3.stat.correlation.PearsonsCorrelation;

public class Correlation 
{
	
	PearsonsCorrelation pearsonsCorrelation = new PearsonsCorrelation();
	
	//double corrVal = pearsonsCorrelation.correlation(toExamine, target);
	
	public List<Map<String, Double>> getCorrelation(List<Map< String, Long>> data, String targetColumnName)	
	{
		List<Map<String, Double>> correlationValues = null;
		
		
		
		//Iterator itr = data
		while()
		{
			
		}
		
		return correlationValues;
	}
	
}
