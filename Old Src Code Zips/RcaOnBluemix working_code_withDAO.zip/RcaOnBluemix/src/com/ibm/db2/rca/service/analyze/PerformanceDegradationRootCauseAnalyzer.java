package com.ibm.db2.rca.service.analyze;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.ibm.db2.rca.service.integration.InputToService;


public class PerformanceDegradationRootCauseAnalyzer 
{
	private InputToService inputToService = null;
	
	@Autowired
	private PerformanceDegradationRootCauseAnalyzerDao performanceDegradationRootCauseAnalyzerDao = null;
	
	public void setInputToService(InputToService inputToService)
	{
		this.inputToService = inputToService;
	}
	
	public PerformanceDegradationRootCauseAnalyzer()
	{		
		System.out.println("performanceDegradationRootCauseAnalyzerDao" + performanceDegradationRootCauseAnalyzerDao);
	}
	
	
	public Object firstStep() throws Exception
	{
		/**		 
		 * Call DAO to fetch data from database			 
		 */
		
		System.out.println("firstStep called.");
		
		List<Map> rows = (List<Map>) performanceDegradationRootCauseAnalyzerDao.queryMonitoredDataForAllComponents_LevelDatabase(inputToService);
		
		
		
		/**
		 * Get Correlation Value for All the Metrics
		 */
		
		/**
		 * 
		 */
		 
		return null;
	}

}
