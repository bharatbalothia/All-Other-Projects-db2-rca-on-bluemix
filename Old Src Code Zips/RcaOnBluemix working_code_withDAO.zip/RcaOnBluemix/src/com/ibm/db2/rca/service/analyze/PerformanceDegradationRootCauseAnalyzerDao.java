package com.ibm.db2.rca.service.analyze;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.ibm.db2.rca.dao.BaseDaoImpl;
import com.ibm.db2.rca.dao.DaoMethodConfig;
import com.ibm.db2.rca.service.integration.InputToService;

public class PerformanceDegradationRootCauseAnalyzerDao extends BaseDaoImpl
{
	public PerformanceDegradationRootCauseAnalyzerDao(NamedParameterJdbcTemplate namedParameterJdbcTemplate) 
	{
		super(namedParameterJdbcTemplate);
	}

	public List<?> queryMonitoredDataForAllComponents_LevelDatabase(InputToService inputToService) throws Exception 
	{	
		Map<String,Object> sqlParamValues = new HashMap<String,Object>();

		/*Following Local class definition is just put here to get the local function name within the function.*/
		System.out.println("queryMonitoredDataForAllComponents_LevelDatabase called.");
		
		class Local{};
		
		String methodName = Local.class.getEnclosingMethod().getName();
		
		System.out.println("Method Name : " + methodName);
		
		DaoMethodConfig daoMethodConfig = (DaoMethodConfig) this.getDaoMethods().get(methodName);				
		
		sqlParamValues.put("startDate", inputToService.getStartDateTime());
		sqlParamValues.put("endDate", inputToService.getEndDateTime());
		sqlParamValues.put("monitoredDbName", inputToService.getMonitoredDbName());
		
		return super.selectList(daoMethodConfig, sqlParamValues);
	}
	
	
}
