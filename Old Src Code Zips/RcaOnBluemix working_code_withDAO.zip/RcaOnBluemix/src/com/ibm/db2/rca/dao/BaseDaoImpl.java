package com.ibm.db2.rca.dao;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.ibm.db2.rca.spring.jdbc.ConfigurableRowMapper;


public abstract class BaseDaoImpl
{	
	private Map<String, DaoMethodConfig> daoMethods = null;
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate = null;
	
	public BaseDaoImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate)
	{
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}
	
	
	public Map<String, DaoMethodConfig> getDaoMethods() {
		return this.daoMethods;
	}

	public void setDaoMethods(Map<String, DaoMethodConfig> daoMethods) {
		this.daoMethods = daoMethods;
	}



	protected MapSqlParameterSource mapSqlParameters(DaoMethodConfig daoMethodConfig, Map<String, Object> values)
	{
		List<String> sqlParams = daoMethodConfig.getSqlParams();
		
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		
		Object value = null;
		
		if(sqlParams != null)
		{
			for(String sqlParamName : sqlParams)
			{
				value = values.get(sqlParamName);
				
				namedParameters.addValue(sqlParamName, value);			
			}
		}
		
		return namedParameters;
	}
	
	protected Object select(DaoMethodConfig daoMethodConfig, Map<String, Object> sqlParamValues) throws Exception
	{
		Object object = null;
		
		if(daoMethodConfig.getCardinality() == BaseDao.Cardinality.RnCn)
		{
			object = this.namedParameterJdbcTemplate.query(daoMethodConfig.getSql(), this.mapSqlParameters(daoMethodConfig,sqlParamValues), new ConfigurableRowMapper(daoMethodConfig));
		}
		else if(daoMethodConfig.getCardinality() == BaseDao.Cardinality.R1Cn)
		{
			object = this.namedParameterJdbcTemplate.queryForObject(daoMethodConfig.getSql(), this.mapSqlParameters(daoMethodConfig,sqlParamValues), new ConfigurableRowMapper(daoMethodConfig));		
		}
		else if(daoMethodConfig.getCardinality() == BaseDao.Cardinality.RnC1)
		{
			object = this.namedParameterJdbcTemplate.queryForList(daoMethodConfig.getSql(), this.mapSqlParameters(daoMethodConfig,sqlParamValues), Class.forName(daoMethodConfig.getClassNameOfObjectsReturned()));		
		}
		else if(daoMethodConfig.getCardinality() == BaseDao.Cardinality.R1C1)
		{
			object = this.namedParameterJdbcTemplate.queryForObject(daoMethodConfig.getSql(), this.mapSqlParameters(daoMethodConfig,sqlParamValues), Class.forName(daoMethodConfig.getClassNameOfObjectsReturned()));		
		}

		return object;
	}
	
	protected List<?> selectList(DaoMethodConfig daoMethodConfig, Map<String, Object> sqlParamValues) throws Exception
	{
		return (List<?>) select(daoMethodConfig, sqlParamValues);
	}
	
	protected Object selectObject(DaoMethodConfig daoMethodConfig, Map<String, Object> sqlParamValues) throws Exception
	{
		return select(daoMethodConfig, sqlParamValues);
	}

//	public List<?> selectRnCnObjects(DaoMethodConfig daoMethodConfig) throws DataAccessException, ClassNotFoundException 
//	{			
//		return this.namedParameterJdbcTemplate.query(daoMethodConfig.getSql(), this.mapSqlParameters(daoMethodConfig), new ConfigurableRowMapper(daoMethodConfig));
//	}
//	
//
//	public List<?> selectRnCn(Map<String,Object> params) throws DataAccessException, ClassNotFoundException 
//	{
//		String sql = null;
//		
//		Map<String, Object>  methodBeanConfig = (Map<String, Object>) params.get("methodBeanConfig");
//		
//		sql = (String) params.get("sql");
//		
//		List<String> sqlParams = (List<String>) methodBeanConfig.get("sqlParams");
//		
//		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
//		
//		if(sqlParams != null)
//		{
//			for(String sqlParamName : sqlParams)
//			{
//				namedParameters.addValue(sqlParamName, params.get(sqlParamName));			
//			}
//		}			
//		return this.namedParameterJdbcTemplate.queryForList(sql, namedParameters);
//	}
//	
//
//	public Object selectR1C1Object(Map<String,Object> params) throws DataAccessException, ClassNotFoundException 
//	{
//		String sql = null;
//		
//		Map<String, Object>  methodBeanConfig = (Map<String, Object>) params.get("methodBeanConfig");
//		
//		sql = (String) params.get("sql");
//		
//		List<String> sqlParams = (List<String>) methodBeanConfig.get("sqlParams");
//		
//		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
//		
//		if(sqlParams != null)
//		{		
//			for(String sqlParamName : sqlParams)
//			{
//				namedParameters.addValue(sqlParamName, params.get(sqlParamName));			
//			}
//		}
//			
//		return this.namedParameterJdbcTemplate.queryForObject(sql, namedParameters, Object.class);
//	}
//	
//	
//	public double selectR1C1Double(Map<String,Object> params) throws DataAccessException, ClassNotFoundException 
//	{			
//		return (Double) this.selectR1C1Object(params);
//	}
}
