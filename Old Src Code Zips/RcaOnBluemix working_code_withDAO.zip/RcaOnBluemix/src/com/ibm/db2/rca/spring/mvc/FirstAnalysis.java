package com.ibm.db2.rca.spring.mvc;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ibm.db2.rca.FirstAnalysisJavaBean;
import com.ibm.db2.rca.service.analyze.PerformanceDegradationRootCauseAnalyzer;
import com.ibm.db2.rca.service.integration.InputToService;
import com.ibm.db2.rca.service.integration.JsonFormInput;

@Controller
@RequestMapping(value="/service/firstAnalysis.do")
public class FirstAnalysis 
{
	@Autowired
	private PerformanceDegradationRootCauseAnalyzer performanceDegradationRootCauseAnalyzer = null;
	
	@RequestMapping(method = RequestMethod.POST, produces={"application/json"})
    public @ResponseBody FirstAnalysisJavaBean firstAnalysisService(@RequestBody JsonFormInput jsonFormInput) throws IOException 
	{

		try 
		{
			InputToService inputToService = new InputToService(jsonFormInput);
			performanceDegradationRootCauseAnalyzer.setInputToService(inputToService);
			performanceDegradationRootCauseAnalyzer.firstStep();
		} 
		catch (Exception e) 
		{		
			System.out.println("Exception.");
			e.printStackTrace();
		}
//		Iterator <String> itr = allRequestParams.keySet().iterator();
//		
//		while (itr.hasNext())
//		{
//			System.out.println("Parameter: " + itr.next());
//		}
//		
		//String jsonBody = IOUtils.toString( request.getInputStream());
		
		//System.out.println("jsonBody : " + jsonBody);
		
		System.out.println("firstAnalysisService method called.");
		
		System.out.println("From Date: " + jsonFormInput.getFromDateTime());
		
		System.out.println("To Date: " + jsonFormInput.getToDateTime());
		
    	FirstAnalysisJavaBean firstAnalysisJavaBean = new FirstAnalysisJavaBean();
    	    	
    	FirstAnalysisJavaBean.Chart chart = firstAnalysisJavaBean.new Chart();
    	
    	List<FirstAnalysisJavaBean.Chart.Label> labels  = new ArrayList<FirstAnalysisJavaBean.Chart.Label>();
    	
    	FirstAnalysisJavaBean.Chart.Label label = chart.new Label();
    	
    	label.setText("A");
    	label.setValue("1");    	
    	labels.add(label);
    	label = chart.new Label();
    	label.setText("B");
    	label.setValue("2");    	
    	labels.add(label);
    	label = chart.new Label();
    	label.setText("C");
    	label.setValue("3");    	
    	labels.add(label);
    	
    	chart.setyAxis(labels);
    	
    	List<Double> values = new ArrayList<Double>();
    	values.add(0.1);
    	values.add(0.3);
    	values.add(0.7);
    	
    	
    	chart.setxAxis(values);
    	
    	firstAnalysisJavaBean.setChart(chart);
    	    	
        return firstAnalysisJavaBean;	
    }

	public FirstAnalysis() {
		System.out.println(this.getClass().getSimpleName() + " : firstAnalysisService called. performanceDegradationRootCauseAnalyzer : " + performanceDegradationRootCauseAnalyzer);
		
		
	}
}
