package com.ibm.db2.rca.util;

public class Utils {


	
	public static boolean isNull(String value)
	{
		boolean isNull = false;
		
		if (value.compareToIgnoreCase("$null$") == 0)
		{
			isNull = true;
		}
		
		return isNull;
	}
	
	public static double stringToDouble(String value)
	{
		double doubleValue = 0.0;
		
		if (!isNull(value))
		{		
			doubleValue = Double.parseDouble(value);
		}
		
		return doubleValue;
	}
	
	public static long stringToLong(String value)
	{
		long doubleValue = 0L;
		
		if (!isNull(value))
		{		
			doubleValue = Long.parseLong(value);
		}
		
		return doubleValue;
	}
	
	public static boolean isEmpty(String value)
	{
		boolean turthness = false;
		
		if(value == null)
			turthness = true;
		else if(value.trim().length() == 0)
			turthness = true;
		else
			turthness = false;
		
		return turthness;
	}
	
}
