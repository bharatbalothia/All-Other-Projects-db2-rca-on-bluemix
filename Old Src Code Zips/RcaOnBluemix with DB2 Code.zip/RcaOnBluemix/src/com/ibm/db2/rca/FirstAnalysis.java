package com.ibm.db2.rca;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;




@Controller
@RequestMapping(value="/service/firstAnalysis.do")
public class FirstAnalysis 
{
	
	
	@RequestMapping(method = RequestMethod.POST, produces={"application/json"})
    public @ResponseBody
    FirstAnalysisJavaBean firstAnalysisService() {

    	FirstAnalysisJavaBean firstAnalysisJavaBean = new FirstAnalysisJavaBean();
    	
    	
    	FirstAnalysisJavaBean.Chart chart = firstAnalysisJavaBean.new Chart();
    	
    	List<FirstAnalysisJavaBean.Chart.Label> labels  = new ArrayList<FirstAnalysisJavaBean.Chart.Label>();
    	
    	FirstAnalysisJavaBean.Chart.Label label = chart.new Label();
    	
    	label.setText("A");
    	label.setValue("1");    	
    	labels.add(label);
    	label = chart.new Label();
    	label.setText("B");
    	label.setValue("2");    	
    	labels.add(label);
    	label = chart.new Label();
    	label.setText("C");
    	label.setValue("3");    	
    	labels.add(label);
    	
    	chart.setyAxis(labels);
    	
    	List<Double> values = new ArrayList<Double>();
    	values.add(0.1);
    	values.add(0.3);
    	values.add(0.7);
    	
    	
    	chart.setxAxis(values);
    	
    	firstAnalysisJavaBean.setChart(chart);
    	
    	
        return firstAnalysisJavaBean;	
    }

	public FirstAnalysis() {
		System.out.println(this.getClass().getSimpleName() + " : Constructor called.");
	}
}
