package com.ibm.db2.rca;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/test")	
public class HomePageController 
{
		@RequestMapping(method = RequestMethod.GET)
		public ModelAndView helloWorld(){
			System.out.println("In the code *******8");
			ModelAndView model = new ModelAndView("yahoo");
			model.addObject("msg", "hello world");	 
			return model;
		}
}
