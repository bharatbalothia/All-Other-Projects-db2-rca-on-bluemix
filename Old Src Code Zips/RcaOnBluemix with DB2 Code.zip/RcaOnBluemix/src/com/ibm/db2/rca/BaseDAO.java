package com.ibm.db2.rca;

import java.sql.Connection;
import java.util.List;
import java.util.Map;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.dao.DataAccessException;

public interface BaseDAO 
{
	
	public void setDataSource(BasicDataSource dataSource);
	
	
	
	public List<?> select(Map<String,Object> params) throws DataAccessException, ClassNotFoundException;

}
