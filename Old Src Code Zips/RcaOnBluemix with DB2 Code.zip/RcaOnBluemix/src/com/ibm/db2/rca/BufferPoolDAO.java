package com.ibm.db2.rca;

import java.util.HashMap;
import java.util.Map;



public class BufferPoolDAO extends BaseDAOImpl 
{
	Map <String,Object> daoMethods = null;	
	
	public Map<String, Object> getDaoMethods() 
	{
		return daoMethods;
	}

	public void setDaoMethods(Map<String, Object> daoMethods) throws Exception 
	{
		this.daoMethods = daoMethods;
		
		System.out.println("Double Value : " + this.getMaxReadResponseTime());
	}
	
		
	public double getMaxReadResponseTime() throws Exception 
	{
	
		double maxReadResponseTime = 0.0;

		Map<String,Object> params = new HashMap<String,Object>();

		/*Following Local class definition is just put there to get the local function name within the function.*/
		class Local{};
		
		String methodName = Local.class.getEnclosingMethod().getName();
		
		Map<String, Object> methodBeanConfig = (Map<String, Object>) daoMethods.get(methodName);
		
		String sql = (String) methodBeanConfig.get("sql");
		
		params.put("sql",sql);
		params.put("methodBeanConfig",methodBeanConfig);
		
		maxReadResponseTime = super.selectOneRowOneColumnDoubleValue(params);

		return maxReadResponseTime;
	}

}
