define([ "dojo/on", "dojo/_base/declare", "dojo/cache", "dijit/_Widget",
		"dijit/_TemplatedMixin", "dijit/_WidgetsInTemplateMixin", 
		"dojo/text!rca/resources/templates/appMain.html", "dojo/_base/lang", "dojo/dom-form" , "dojo/json", "dijit/registry",
		"dojo/domReady!",
		"dijit/layout/BorderContainer", "dijit/layout/ContentPane", "dijit/form/DateTextBox", "dijit/form/TimeTextBox", 
		"dijit/form/Form" , "dijit/form/Button" , 
		"dojox/charting/Chart2D",
		"dojo/data/ItemFileWriteStore",
		"dojox/charting/plot2d/Bars"
		
		], 
		function(on, declare, cache, _Widget, _TemplatedMixin, _WidgetsInTemplateMixin, template, lang, domForm, json, registry) {
	
		return declare('rca.appMain',[ _Widget, _TemplatedMixin,
			_WidgetsInTemplateMixin ], {
		
		templateString : template,
		
		baseClass: "appMain",
		
		// Path to the template
		

		// Override this method to perform custom behavior during dijit construction.
		// Common operations for constructor:
		// 1) Initialize non-primitive types (i.e. objects and arrays)
		// 2) Add additional properties needed by succeeding lifecycle methods
		constructor : function() {
			console.debug("I am inside constructor.");		
		},

		// When this method is called, all variables inherited from superclasses are 'mixed in'.
		// Common operations for postMixInProperties
		// 1) Modify or assign values for widget property variables defined in the template HTML file
		postMixInProperties : function() {
		},

		startup : function(){
			console.debug("Startup Function called.");
	    	   
		},
		
		// postCreate() is called after buildRendering().  This is useful to override when 
		// you need to access and/or manipulate DOM nodes included with your widget.
		// DOM nodes and widgets with the dojoAttachPoint attribute specified can now be directly
		// accessed as fields on "this". 
		// Common operations for postCreate
		// 1) Access and manipulate DOM nodes created in buildRendering()
		// 2) Add new DOM nodes or widgets 
		postCreate : function() {
			
			this.inherited(arguments);
			
		},
		
		
		fromTimeValueChanged : function(/* event */ event)
		{
//			require(['dojo/dom'], 
					//function(dom){dom.byId('val').value=dom.byId('toDateId').value.toString().replace(/.*1970\s(\S+).*/,'T$1')
				//});
			console.debug("fromDateChanged");	
			
			console.debug(event);
			
				
		},
		
		toTimeValueChanged : function(/* event */ event)
		{
			console.debug("toDateChanged");
			
			console.debug(event);
		},
		
		processServerSuccessResponse : function(jsonData) {
			
			console.debug("Successfully submitted form.");
			
			//var store = new dojo.data.ItemFileWriteStore({ url:"appMain.json" });
			
			var oldBars = registry.byId("initialMetricsChartId");
			
			if(oldBars)
				{
				console.debug("found old bars");
					oldBars.destroy();
				}
			
			bars = new dojox.charting.Chart("initialMetricsChartId",{
				title: "Performance Matrices",
    			titlePos: "bottom",
    			titleGap: 25,
    			titleFont: "normal normal normal 15pt 'Segoe UI'",
    			titleFontColor: "black"
			});
			
			
			//bars.setStore(store, {symbol:"*"}, "price");
			bars.addPlot("default", {type: dojox.charting.plot2d.Bars, length:10, minBarSize: 20, maxBarSize : 20});		
			bars.addAxis("x",{min:0, max: 1});
			bars.addAxis("y", {vertical: true, labels: jsonData['chart']['yAxis'] });						
			bars.addSeries("Series 1", jsonData['chart']['xAxis'], {stroke: {color:"rgb(0,0,80)"}, fill:"rgb(0,0,80)" }
    		);
			
			bars.render();
	    			
		},
			
		processServerErrorResponse : function(){
			console.debug("Failed in form submission.");
		},
		
		submitFormAsJson : function () {
			
			
			console.debug("submitFormAsJson called.");
			var successCallback = lang.hitch(this, "processServerSuccessResponse");
			
			var errorCallback = lang.hitch(this, "processServerErrorResponse");
		
			var data = domForm.toJson("firstInputFormId");
			
			
			var firstAnalysisService = {
					data: data,					
					url: "service/firstAnalysis.do",
					handleAs: "json",
					method: "post",
					preventCache: true,
					load: successCallback,
					error: errorCallback
			};
			
			dojo.xhrPost(firstAnalysisService);
				
			
		}
		

		

		
	});
	

    
});